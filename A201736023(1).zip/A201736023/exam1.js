let s = "one, two three four   five   ";
console.log(s.replace(/ /g,""));