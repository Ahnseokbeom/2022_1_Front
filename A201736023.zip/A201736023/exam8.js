let num = 3;
for(let i = 1;i<=9;i++){
    console.log(num+" * "+i+" = "+num*i);
}