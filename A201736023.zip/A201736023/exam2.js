let person1 = {name : "홍길동", age : 16};
let person2 = person1.slice(0);
person2.age = 18;
console.log(person1);
console.log(person2);