<template>
  <div class="exam2">
    <h1>Exam2</h1>
  </div>
</template>
