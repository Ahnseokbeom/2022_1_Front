<template>
  <div class="id">
      <h1>hello</h1>
  </div>
</template>
<script>
</script>
<style scoped>
 div{
     background-color: black;
 }
</style>
