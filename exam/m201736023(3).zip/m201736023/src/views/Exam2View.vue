<template>
  <div class="exam2">
    <h1>Exam2</h1>
  </div>
  <input type="number" v-model="value1"/><br />
  <input type="number" v-model="value2"/><br />
  <Exam2Child value1 = "hello" title="hello"></Exam2Child>
  <exam-2-child />
</template>
<script>
import Exam2Child from '../components/Exam2Child.vue'
export default {
    components : {
        Exam2Child
    },
    data(){
        let value1 = 0
        let value2 = 0
        let sum = value1+value2
        return {
            sum
        }
    }
}
</script>
