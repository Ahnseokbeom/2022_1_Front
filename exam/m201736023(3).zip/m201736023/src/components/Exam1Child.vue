<template>
  <div class="id">
      <h1>{{title}}</h1>
  </div>
</template>
<script>
export default {
    name : 'Exam1Child',
    props : {
        title : String
    },
    data() {
            return {
                pvalue: this.value
        }
        },
        //     methods: {
        //     myChange($event) {
        //         this.$emit('input', $event.target.value);
        //     },
        // },
}
</script>
<style scoped>
 div{
     background-color: greenyellow;
 }
</style>
