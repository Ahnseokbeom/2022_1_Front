<template>
  <div class="exam2">
    <h1>Exam2</h1>
  </div>
  <input type="number" v-model="value1"/><br />
  <input type="number" v-model="value2"/><br />
 <Exam2Child v-bind:value1 = value1 v-bind:value2=value2 v-bind:title = sum></Exam2Child>
</template>
<script>
import Exam2Child from '../components/Exam2Child.vue'
export default {
    components : {
        Exam2Child
    },
    data(){
        let value1=0, 
        let value2=0,
        let sum = this.value1+this.value2;
        return {
            sum
        }
    }
}
</script>
