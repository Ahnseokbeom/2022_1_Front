<template>
  <div class="id">
      <h1>{{title}}</h1>
  </div>
</template>
<script>
export default {
    name : 'Exam1Child',
    props : ["title"],
}
</script>
<style scoped>
 div{
     background-color: greenyellow;
 }
</style>
